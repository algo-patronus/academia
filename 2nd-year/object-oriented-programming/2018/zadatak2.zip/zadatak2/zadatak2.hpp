#ifndef __ZADATAK_2_HPP_
#define __ZADATAK_2_HPP_

#include <stddef.h>

size_t broj_kolona();

void pauziraj(unsigned int msec);

#endif /* ifndef __ZADATAK_2_HPP_ */